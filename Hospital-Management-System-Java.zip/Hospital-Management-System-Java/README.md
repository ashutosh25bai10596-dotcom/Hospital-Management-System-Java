# Hospital Management System using Java

A console-based Hospital Management System demonstrating core Java and Object-Oriented Programming concepts.

## Features
- Patient registration and viewing
- Doctor management
- Appointment scheduling
- Billing management
- Input validation and exception handling
- Dynamic record storage using ArrayList

## OOP Concepts
- Encapsulation
- Inheritance
- Polymorphism
- Abstraction
- Classes and Objects
- Exception Handling
- Collections

## Technologies
- Java
- JDK 17 or later
